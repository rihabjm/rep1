import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MembreComponent } from './membre/membre.component';
import {MembreAddComponent } from './membre-add/membre-add.component';
import { MembreUpdateComponent} from './membre-update/membre-update.component';
import { MembreDeleteComponent} from './membre-delete/membre-delete.component';
import { MembreValideComponent} from './membre-valide/membre-valide.component';
import { MembreListComponent } from './membre-list/membre-list.component';
const routes: Routes = [
{
        path: 'membre',
        component: MembreComponent,
        children: [
            {
                path: 'add',
                component: MembreAddComponent
            },
            {
                path: 'update',
                component: MembreUpdateComponent
            }
,
            {
                path: 'delete',
                component: MembreDeleteComponent
            } ,

           {
                path: 'valide',
                component: MembreValideComponent
            }
,

           {
                path: 'list',
                component: MembreListComponent
            }
        ]
    }



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MembreRoutingModule { }
